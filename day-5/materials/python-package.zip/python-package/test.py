from DS.LL import *
import DS.Graph as dsg
from DS.Graph import graph
from DS.Array import array


ll.print_module()
ll.travarsal(None)

dll.print_module()
dll.travarsal(None)

graph.print_module()
graph.travarsal(None)

array.print_module()
array.travarsal(None)

print("graph is a ", type(graph))
print("DS.Graph is a ", type(dsg))

