def print_module():
    print(f"I am {__name__}")
def travarsal(head):
    print('Travarsing an array')
def create(head):
    print('Creating an array')
def deleteIndex(index):
    print('Deleting an index in array')

