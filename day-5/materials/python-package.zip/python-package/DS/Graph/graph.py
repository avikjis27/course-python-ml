def print_module():
    print(f"I am {__name__}")
def travarsal(root):
    print('Travarsing a graph')
def create(root):
    print('Creating a a graph')
def deleteNode(root):
    print('Deleting a node in a graph')

