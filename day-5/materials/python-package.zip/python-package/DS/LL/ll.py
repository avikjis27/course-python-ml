def print_module():
    print(f"I am {__name__}")
def reversal(head):
    print('Linked list reversal operation')
def travarsal(head):
    print('Travarsing linked list')
def create(head):
    print('Creating a linked list')
def deleteNode(node):
    print('Deleting a node in linked list')

