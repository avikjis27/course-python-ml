def print_module():
    print(f"I am {__name__}")
def reversal(head):
    print('D-Linked list reversal operation')
def travarsal(head):
    print('Travarsing D-linked list')
def create(head):
    print('Creating a D-linked list')
def deleteNode(node):
    print('Deleting a node in D-linked list')

