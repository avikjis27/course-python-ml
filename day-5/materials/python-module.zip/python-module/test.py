#export PYTHONPATH="$PWD/LL"
import ll
import sys
print(sys.path)
print(dir(ll))
print(__name__)
ll.print_module()
ll.reversal(None)
print(type(ll))
